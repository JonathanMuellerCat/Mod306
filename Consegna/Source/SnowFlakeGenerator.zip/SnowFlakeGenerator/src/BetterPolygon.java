import java.awt.Point;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Area;
import java.awt.geom.PathIterator;
import java.util.ArrayList;

/**
 * Classe che estende Polygon
 * @author Jonathan Mueller
 * @version 15.12.2019
 */
public class BetterPolygon extends Polygon {

    /**
     * Costruttore di Polygon.
     * @param xpoints Le posizioni x dei punti
     * @param ypoints Le posizioni y dei punti
     * @param npoints Il numero di punti
     */
    public BetterPolygon(int[] xpoints, int[] ypoints, int npoints) {
        super(xpoints, ypoints, npoints);
    }

    /**
     * Costruttore vuoto di Polygon.
     */
    public BetterPolygon() {
        super();
    }

    /**
     * Costruttore che permette di creare BetterPolygon direttamente da punti.
     * @param punti I punti del poligono
     */
    public BetterPolygon(ArrayList<Point> punti) {
        super();
        for (Point point : punti) {
            this.addPoint(point.x, point.y);
        }
    }
    
    /**
     * Aggiunge un punto al poligono.
     * @param p Il punto da aggingere
     */
    public void addPoint(Point p){
        this.addPoint(p.x, p.y);
    }
    
    /**
     * Controlla se un poligono è contenuto in questo poligono.
     * @param p Il poligono contenuto
     * @return Se il poligono è contenuto (true) o no (false)
     */
    public boolean contains(BetterPolygon p) {
        ArrayList<Point> points = p.getPoints();
        boolean contains = true; 
        for (Point point : points) {
            if(!this.contains(point)){
                contains = false;
            }
        }
        return contains;
    }
    
    /**
     * Controlla se un poligono intereca questo poligono.
     * @param p Il poligono che interseca
     * @return Se il poligono interseca (true) o no (false)
     */
    public boolean intersects(BetterPolygon p) {
        Area pArea = new Area(p);
        Area thisArea = new Area(this);
        thisArea.intersect(pArea);
        return !thisArea.isEmpty();
    }
    
    /**
     * Fonde un poligono a questo poligono se i due si intersecano
     * @param p Il poligono da aggiungere
     */
    public void combine(BetterPolygon p) {
        if(this.intersects(p)){
            Area pArea = new Area(p);
            Area thisArea = new Area(this);
            thisArea.add(pArea);
            PathIterator iterator = thisArea.getPathIterator(null);
            float[] floats = new float[6];
            BetterPolygon polygon = new BetterPolygon();
            while (!iterator.isDone()) {
                int type = iterator.currentSegment(floats);
                int x = (int) floats[0];
                int y = (int) floats[1];
                if(type != PathIterator.SEG_CLOSE) {
                    polygon.addPoint(x, y);
                }
                iterator.next();
            }
            this.reset();
            ArrayList<Point> points = polygon.getPoints();
            for (Point point : points) {
                this.addPoint(point.x, point.y);
            }
        }
    }
    
    /**
     * Metodo getter di points.
     * @return I punti del poligono
     */
    public ArrayList<Point> getPoints(){
        ArrayList<Point> points = new ArrayList<>();
        for (int i = 0; i < this.npoints; i++) {
            points.add(new Point(this.xpoints[i], this.ypoints[i]));
        }
        return points;
    }
    
    /**
     * Metodo getter di un punto specifico.
     * @param i L'indice del punto
     * @return Il punto indicizzato da i
     */
    public Point getPoint(int i){
        ArrayList<Point> points = this.getPoints();
        return points.get(i);
    }
    
    /**
     * Ritorna il numero di punti del poligono
     * @return Il numero di punti
     */
    public int getSize(){
        ArrayList<Point> points = this.getPoints();
        return points.size();
    }
    
    /**
     * Sottrae un poligono contenuto in questo poligono ad esso.
     * @param p Il poligono da sottrarre
     */
    public void subtract(BetterPolygon p){
        if(this.contains(p) && this.getSize() > 2){
            Point thisLastPoint = this.getPoint(this.getSize() - 1);
            Point pLastPoint = null;
            ArrayList<Point> points = p.getPoints();
            for (Point point : points) {
                this.addPoint(point.x, point.y);
                if(pLastPoint == null){
                    pLastPoint = new Point(point.x, point.y);
                }
            }
            if (pLastPoint != null) {
                this.addPoint(pLastPoint.x, pLastPoint.y);
            }
            this.addPoint(thisLastPoint.x, thisLastPoint.y);
        }
    }
    
    /**
     * Ritorna una copia di questo poligono roteato attorno ad un punto.
     * @param center Il punto da ruotare attorno
     * @param amount Di quanto ruotare in gradi
     * @return Il poligono roteato
     */
    public BetterPolygon getPolygonRotatedAroundPointV3(Point center, Double amount){
        AffineTransform at = new AffineTransform();
        at.rotate(Math.toRadians(amount), center.x, center.y);
        Shape shape = at.createTransformedShape(this);
        BetterPolygon polygon = BetterPolygon.parsePolygon(shape);
        return polygon;
    }
    
    /**
     * Ritorna una copia del poligono ridimensionato.
     * @param center Il centro che rimarra fermo
     * @param amount Le proporzioni del ridimensionamento
     * @param bounds Lo spazio che il poligono occupava (nel caso sia stato tagliato)
     * @return Il poligono ridimensionato
     */
    public BetterPolygon getResizedPolygonV3(Point center, double amount, Rectangle bounds){
        AffineTransform at = new AffineTransform();
        int x = bounds.x;
        int y = bounds.y;
        at.translate(-x, -y);
        at.scale(amount, amount);
        at.translate(x*3, y*3);
        Shape shape = at.createTransformedShape(this);
        BetterPolygon polygon = BetterPolygon.parsePolygon(shape);
        return polygon;
    }
    
    /**
     * Ritorna una copia del poligono specchiato da un asse.
     * @param center Un punto dell'asse
     * @param bounds Lo spazio che il poligono occupava (nel caso sia stato tagliato)
     * @return Il poligono specchiato
     */
    public BetterPolygon getMirroredPolygon(Point center, Rectangle bounds){
        AffineTransform at = new AffineTransform();
        int x = bounds.x;
        int y = bounds.y;
        at.translate(-x, -y);
        at.scale(-1, 1);
        at.translate(-(x * 2 + bounds.width + center.x), y);
        Shape shape = at.createTransformedShape(this);
        BetterPolygon polygon = BetterPolygon.parsePolygon(shape);
        return polygon;
    }
    
    /**
     * Ritorna una copia del poligono spostato di alcunti pixel.
     * @param x Lo spostamento orizzontale
     * @param y Lo spostamento verticael
     * @return Il poligono spostato
     */
    public BetterPolygon getMovePolygonV3(int x, int y){
        AffineTransform at = new AffineTransform();
        at.translate(x, y);
        Shape shape = at.createTransformedShape(this);
        BetterPolygon polygon = BetterPolygon.parsePolygon(shape);
        return polygon;
    }
    
    /**
     * Trasforma un'area in un poligono.
     * @param area L'area da trasformare
     * @return Il poligono
     */
    public static BetterPolygon parsePolygon(Area area){
        PathIterator iterator = area.getPathIterator(null);
        float[] floats = new float[6];
        BetterPolygon polygon = new BetterPolygon();
        Point closingPoint = null;
        ArrayList<Point> closingPoints = new ArrayList<>();
        while (!iterator.isDone()) {
            int type = iterator.currentSegment(floats);
            int px = (int) floats[0];
            int py = (int) floats[1];
            polygon.addPoint(px, py);
            if(type == 0){
                closingPoint = new Point(px,py);
                closingPoints.add(closingPoint);
            }
            if(type == 4){
                polygon.addPoint(closingPoint);
            }
            iterator.next();
        }
        for (Point finalClosingPoint : closingPoints) {
            polygon.addPoint(finalClosingPoint);
        }
        return polygon;
    }
    
    /**
     * Trasforma una shape in un poligono.
     * @param shape La shape da trasformare
     * @return Il poligono
     */
    public static BetterPolygon parsePolygon(Shape shape){
        PathIterator iterator = shape.getPathIterator(null);
        float[] floats = new float[6];
        BetterPolygon polygon = new BetterPolygon();
        Point closingPoint = null;
        ArrayList<Point> closingPoints = new ArrayList<>();
        while (!iterator.isDone()) {
            int type = iterator.currentSegment(floats);
            int px = (int) floats[0];
            int py = (int) floats[1];
            polygon.addPoint(px, py);
            if(type == 0){
                closingPoint = new Point(px,py);
                closingPoints.add(closingPoint);
            }
            if(type == 4){
                polygon.addPoint(closingPoint);
            }
            iterator.next();
        }
        for (Point finalClosingPoint : closingPoints) {
            polygon.addPoint(finalClosingPoint);
        }
        return polygon;
    }
}
