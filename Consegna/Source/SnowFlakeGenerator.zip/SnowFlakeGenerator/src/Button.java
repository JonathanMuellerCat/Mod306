
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import java.util.List;

/**
 * Modello astratto di un bottone rotondo che ingrandisce quando ci passo sopra.
 * @author Jonathan Mueller
 * @version 15.12.2019
 */
public class Button implements MouseListener, MouseMotionListener {
    
    /**
     * La posizione x del centro
     */
    private int centerX;
    
    /**
     * La posizione y del centro
     */
    private int centerY;
    
    /**
     * Il raggio del bottone
     */
    private int radius;
    
    /**
     * La stringa scritta nel bottone
     */
    private String string;
    
    /**
     * Il nome identificatore del bottone
     */
    private String name;
    
    /**
     * Le proporzioni di ingrandimento del bottone
     */
    private static final double MULTIPLIER = 1.5;
    
    /**
     * Se il bottone si trova sotto il mouse
     */
    private boolean hover = false;
    
    /**
     * I listener del bottone
     */
    private List<ButtonListener> listeners = new ArrayList<ButtonListener>();

    /**
     * Costruttore di Button.
     * @param centerX La posizione x del centro
     * @param centerY La posizione y del centro
     * @param radius Il raggio del bottone
     * @param string La stringa scritta nel bottone
     * @param name Il nome identificatore del bottone
     */
    public Button(int centerX, int centerY, int radius, String string, String name) {
        this.centerX = centerX;
        this.centerY = centerY;
        this.radius = radius;
        this.string = string;
        this.name = name;
    }

    /**
     * Ridimensiona il bottone.
     * @param centerX La posizione x del centro
     * @param centerY La posizione y del centro
     * @param radius Il raggio del bottone
     */
    public void setSizeAndPosition(int centerX, int centerY, int radius) {
        this.centerX = centerX;
        this.centerY = centerY;
        this.radius = radius;
    }

    /**
     * Controlla quando il mouse è cliccato.
     * @param e L'evento del mouse
     */
    @Override
    public void mouseClicked(MouseEvent e) {
        if(this.contains(e.getPoint())){
            for (ButtonListener listener : this.listeners) {
                listener.Button_clicked(this.name);
            }
        }
    }

    /**
     * Controlla quando il mouse è premuto.
     * @param e L'evento del mouse
     */
    @Override
    public void mousePressed(MouseEvent e) {
    }

    /**
     * Controlla quando il mouse è rilasciato.
     * @param e L'evento del mouse
     */
    @Override
    public void mouseReleased(MouseEvent e) {
    }

    /**
     * Controlla quando il mouse entra nel frame.
     * @param e L'evento del mouse
     */
    @Override
    public void mouseEntered(MouseEvent e) {
    }

    /**
     * Controlla quando il mouse esce dal frame.
     * @param e L'evento del mouse
     */
    @Override
    public void mouseExited(MouseEvent e) {
    }

    /**
     * Controlla quando il mouse viene trascinato.
     * @param e L'evento del mouse
     */
    @Override
    public void mouseDragged(MouseEvent e) {
    }

    /**
     * Controlla quando il mouse viene mosso.
     * @param e L'evento del mouse
     */
    @Override
    public void mouseMoved(MouseEvent e) {
        if (this.hover) {
            if (!this.contains(e.getPoint())) {
                for (ButtonListener listener : this.listeners) {
                    listener.Button_mouseExited(this.centerX, this.centerY, this.radius, MULTIPLIER);
                    this.hover = false;
                }
            }
        }else{
            if (this.contains(e.getPoint())) {
                for (ButtonListener listener : this.listeners) {
                    listener.Button_mouseEntered(this.centerX, this.centerY, this.radius, MULTIPLIER);
                    this.hover = true;
                }
            }
        }
        
    }
    
    /**
     * Controlla se un punto si trova all'interno del bottone.
     * @param p Il punto
     * @return Se punto si trova all'interno del bottone
     */
    public boolean contains(Point p){
        return (p.distance(this.centerX, this.centerY) <= this.radius);
    }
    
    /**
     * Aggiunge un listener.
     * @param bl Il listener
     */
    public void addButtonListener(ButtonListener bl){
        this.listeners.add(bl);
    }
    
    /**
     * Rimuove un listener.
     * @param bl Il listener
     */
    public void removeButtonListener(ButtonListener bl){
        this.listeners.remove(bl);
    }
    
    /**
     * Disegna il bottone.
     * @param g Il contesto grafico
     */
    public void paint(Graphics g){
        double multiplier = ((this.hover)?(MULTIPLIER):(1.0));
        g.setFont(new Font("monospaced", Font.PLAIN, (int)Math.round(((double)(this.radius*2)/(double)this.string.length()) * 1.4 * multiplier)));
        g.setColor(new Color(200,200,200));
        g.fillOval(this.centerX - (int)Math.round(this.radius * multiplier), this.centerY - (int)Math.round(this.radius * multiplier), (int)Math.round(this.radius * 2 * multiplier), (int)Math.round(this.radius * 2 * multiplier));
        g.setColor(Color.BLACK);
        g.drawOval(this.centerX - (int)Math.round(this.radius * multiplier), this.centerY - (int)Math.round(this.radius * multiplier), (int)Math.round(this.radius * 2 * multiplier), (int)Math.round(this.radius * 2 * multiplier));
        g.drawString(string, this.centerX - (int)Math.round(this.radius * multiplier) + (int)Math.round(this.radius * multiplier * 0.2), this.centerY + (int)Math.round(((double)this.radius/(double)this.string.length() * 2.5) * multiplier) / 2);
    }
}
