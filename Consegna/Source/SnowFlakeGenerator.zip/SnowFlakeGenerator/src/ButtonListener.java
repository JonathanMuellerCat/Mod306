/**
 * Interfaccia di Button
 * @author Jonathan Mueller
 * @version 15.12.2019
 */
public interface ButtonListener {

    /**
     * Controlla quando il mouse entra nel bottone.
     * @param centerX La posizione x del centro
     * @param centerY La posizione y del centro
     * @param radius Il raggio del bottone
     * @param multiplier Le proporzioni di ingrandimento del bottone
     */
    public void Button_mouseEntered(int centerX, int centerY, int radius, double multiplier);

    /**
     * Controlla quando il mouse esce dal bottone.
     * @param centerX La posizione x del centro
     * @param centerY La posizione y del centro
     * @param radius Il raggio del bottone
     * @param multiplier Le proporzioni di ingrandimento del bottone
     */
    public void Button_mouseExited(int centerX, int centerY, int radius, double multiplier);

    /**
     * Controlla quando il bottone viene premuto.
     * @param name Il nome del bottone premuto
     */
    public void Button_clicked(String name);
    
}
