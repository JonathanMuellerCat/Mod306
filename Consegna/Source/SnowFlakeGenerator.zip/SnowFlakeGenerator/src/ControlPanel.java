
import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import javax.swing.JPanel;

/**
 * Pannello che contiene i bottoni per controllare il fiocco di neve.
 * @author Jonathan Mueller
 * @version 15.12.2019
 */
public class ControlPanel extends JPanel implements ButtonListener {
    
    /**
     * Bottone per generare il fiocco
     */
    private Button genera = new Button(-50,60,25,"Genera","genera");
    
    /**
     * Bottone per resettare i punti
     */
    private Button reset = new Button(-125,60,25,"Reset","reset");
    
    /**
     * Bottone per mostrare una demo del triangolo tagliato
     */
    private Button demo = new Button(-200,60,25,"Demo","showDemo");
    
    /**
     * Bottone per salvare il punti in un file
     */
    private Button salvaPunti = new Button(50,60,25,"Salva","salvaPunti");
    
    /**
     * Bottone per caricare i punti da un file
     */
    private Button caricaPunti = new Button(125,60,25,"Carica","caricaPunti");
    
    /**
     * Bottone per salvare il fiocco come immagine
     */
    private Button salvaImmagine = new Button(200,60,25,"Esporta","salvaImmagine");
    
    /**
     * I listener di ControlPanel
     */
    ArrayList<ControlPanelListener> listeners = new ArrayList<>();
    
    /**
     * Metodo costruttore di ControlPanel.
     */
    public ControlPanel() {
        super();
        this.addMouseListener(this.genera);
        this.addMouseMotionListener(this.genera);
        this.genera.addButtonListener(this);
        this.addMouseListener(this.reset);
        this.addMouseMotionListener(this.reset);
        this.reset.addButtonListener(this);
        this.addMouseListener(this.demo);
        this.addMouseMotionListener(this.demo);
        this.demo.addButtonListener(this);
        this.addMouseListener(this.salvaPunti);
        this.addMouseMotionListener(this.salvaPunti);
        this.salvaPunti.addButtonListener(this);
        this.addMouseListener(this.caricaPunti);
        this.addMouseMotionListener(this.caricaPunti);
        this.caricaPunti.addButtonListener(this);
        this.addMouseListener(this.salvaImmagine);
        this.addMouseMotionListener(this.salvaImmagine);
        this.salvaImmagine.addButtonListener(this);
    }
    
    /**
     * Controlla quando il mouse esce dal bottone.
     * @param centerX La posizione x del centro
     * @param centerY La posizione y del centro
     * @param radius Il raggio del bottone
     * @param multiplier Le proporzioni di ingrandimento del bottone
     */
    @Override
    public void Button_mouseExited(int centerX, int centerY, int radius, double multiplier) {
        repaint(centerX - (int)Math.round(radius * multiplier) - 1, centerY - (int)Math.round(radius * multiplier) - 1, (int)Math.round(radius * 2 * multiplier) + 2, (int)Math.round(radius * 2 * multiplier) + 2);
    }
    
    /**
     * Controlla quando il mouse entra nel bottone.
     * @param centerX La posizione x del centro
     * @param centerY La posizione y del centro
     * @param radius Il raggio del bottone
     * @param multiplier Le proporzioni di ingrandimento del bottone
     */
    @Override
    public void Button_mouseEntered(int centerX, int centerY, int radius, double multiplier) {
        repaint(centerX - (int)Math.round(radius * multiplier) - 1, centerY - (int)Math.round(radius * multiplier) - 1, (int)Math.round(radius * 2 * multiplier) + 2, (int)Math.round(radius * 2 * multiplier) + 2);
    }

    /**
     * Controlla quando il bottone viene premuto.
     * @param name Il nome del bottone premuto
     */
    @Override
    public void Button_clicked(String name) {
        for (ControlPanelListener listener : listeners) {
            listener.ControlPanel_buttonClick(name);
        }
    }

    /**
     * Disegna il pannello.
     * @param g Il contesto grafico
     */
    @Override
    public void paintComponent(Graphics g) {
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, this.getWidth(), this.getHeight());
        this.genera.setSizeAndPosition(this.getWidth() - 50, this.getHeight() - 50, 25);
        this.genera.paint(g);
        this.reset.setSizeAndPosition(this.getWidth() - 125, this.getHeight() - 50, 25);
        this.reset.paint(g);
        this.demo.setSizeAndPosition(this.getWidth() - 200, this.getHeight() - 50, 25);
        this.demo.paint(g);
        this.salvaPunti.setSizeAndPosition(50, this.getHeight() - 50, 25);
        this.salvaPunti.paint(g);
        this.caricaPunti.setSizeAndPosition(125, this.getHeight() - 50, 25);
        this.caricaPunti.paint(g);
        this.salvaImmagine.setSizeAndPosition(200, this.getHeight() - 50, 25);
        this.salvaImmagine.paint(g);
    }
    
    /**
     * Aggiunge un listener.
     * @param cpl Il listener
     */
    public void addControlPanelListener(ControlPanelListener cpl){
        this.listeners.add(cpl);
    }
    
    /**
     * Rimuove un listener.
     * @param cpl Il listener
     */
    public void removeControlPanelListener(ControlPanelListener cpl){
        this.listeners.remove(cpl);
    }
}