/**
 * Interfaccia di ControlPanel
 * @author Jonathan Mueller
 * @version 15.12.2019
 */
public interface ControlPanelListener {

    /**
     * Controlla quando un bottone viene premuto.
     * @param name Il nome del bottone premuto
     */
    public void ControlPanel_buttonClick(String name);
    
}
