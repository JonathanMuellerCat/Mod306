
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;

/**
 * Punto che permette di creare un CuttingPolygon
 * @author Jonathan Mueller
 * @version 15.12.2019
 */
public class CuttingPoint implements MouseListener, MouseMotionListener {
    
    /**
     * Il diametro del punto
     */
    private final int DIAMETER = 10;
    
    /**
     * La posizione x del punto relativa al centro del frame
     */
    private double x;
    
    /**
     * La posizione y del punto relativa al centro del frame
     */
    private double y;
    
    /**
     * La posizione x del centro del frame
     */
    private double centerX;
    
    /**
     * La posizione y del centro del frame
     */
    private double centerY;
    
    /**
     * L'altezza del frame
     */
    private double height;
    
    /**
     * La larghezza del frame
     */
    private double width;
    
    /**
     * Il punto sta venendo mosso, e segue la posizione del mouse
     */
    private boolean dragging = false;
    
    /**
     * CuttingPoint connesso a questo punto
     */
    private CuttingPoint connectedWith = null;
    
    /**
     * Questo è il primo punto, è verde e chiude il CuttingPolygon quando cliccato
     */
    private boolean firstPoint = false;
    
    /**
     * I listener
     */
    private ArrayList<CuttingPointListener> listeners = new ArrayList<>();
    
    /**
     * Il punto può essere mosso
     */
    private boolean canMove = true;
    
    /**
     * Metodo costruttore.
     * @param x La posizione x del punto relativa al centro del frame
     * @param y La posizione y del punto relativa al centro del frame
     * @param centerX La posizione x del centro del frame
     * @param centerY La posizione y del centro del frame
     * @param width L'altezza del frame
     * @param height La larghezza del frame
     */
    public CuttingPoint(double x, double y, double centerX, double centerY, double width, double height) {
        this.x = x;
        this.y = y;
        this.centerX = centerX;
        this.centerY = centerY;
        this.height = height;
        this.width = width;
    }

    /**
     * Setter di connectedWith.
     * @param cp CuttingPoint connesso a questo punto
     */
    public void setConnectedWith(CuttingPoint cp) {
        this.connectedWith = cp;
    }

    /**
     * Setter di firstPoint.
     * @param firstPoint Questo è il primo punto, è verde e chiude il CuttingPolygon quando cliccato
     */
    public void setFirstPoint(boolean firstPoint) {
        this.firstPoint = firstPoint;
    }
    
    /**
     * Setter di canMove.
     * @param canMove Il punto può essere mosso
     */
    public void canMove(boolean canMove){
        this.canMove = canMove;
    }

    /**
     * Getter di x.
     * @return La posizione x del punto relativa al centro del frame
     */
    public double getX() {
        return x;
    }

    /**
     * Getter di y.
     * @return La posizione y del punto relativa al centro del frame
     */
    public double getY() {
        return y;
    }
    
    /**
     * Ridimensiona il punto.
     * @param width L'altezza del frame
     * @param height La larghezza del frame
     * @param centerX La posizione x del centro del frame
     * @param centerY La posizione y del centro del frame
     */
    public void setSizeAndPosition(double height, double width, double centerX, double centerY) {
        this.x = this.x / this.width * width;
        this.y = this.y / this.height * height;
        this.height = height;
        this.width = width;
        this.centerX = centerX;
        this.centerY = centerY;
    }
    
    /**
     * Disegna il punto e la righa di connessione.
     * @param g Il contesto grafico
     */
    public void paint(Graphics g){
        Color blue = new Color(0, 0, 255, 255);
        g.setColor(blue);
        if(this.connectedWith != null){
            g.drawLine((int)Math.round(this.centerX + this.x), (int)Math.round(this.centerY + this.y),(int)Math.round(this.connectedWith.centerX + this.connectedWith.x), (int)Math.round(this.connectedWith.centerY + this.connectedWith.y));
        }
        Color point = new Color(255, 0, 0, 200);
        if(this.firstPoint){
            point = new Color(0, 255, 0, 200);
        }
        g.setColor(point);
        g.fillOval((int)Math.round(this.centerX + this.x - DIAMETER/2), (int)Math.round(this.centerY + this.y - DIAMETER/2), DIAMETER, DIAMETER);
    }
    
    /**
     * Controlla se un punto è contenuto in questo CuttingPoint.
     * @param p Il punto da controllare
     * @return Se è contenuto (true) oppure no (false)
     */
    public boolean contains(Point p){
        return (p.distance((int)Math.round(this.centerX + this.x), (int)Math.round(this.centerY + this.y)) <= DIAMETER / 2);
    }

    /**
     * Controlla quando il mouse è cliccato.
     * @param e L'evento del mouse
     */
    @Override
    public void mouseClicked(MouseEvent e) {
        if(this.contains(e.getPoint())){
            if(this.firstPoint && e.getButton() == MouseEvent.BUTTON1){
                for (CuttingPointListener listener : listeners) {
                    listener.CuttingPoint_firstPointClicked();
                }
            }else if(e.getButton() == MouseEvent.BUTTON3){
                try {
                    for (CuttingPointListener listener : listeners) {
                        listener.CuttingPoint_pointRemoved(this);
                    }
                } catch (ConcurrentModificationException cme) {
                }
            }
        }
    }

    /**
     * Controlla quando il mouse è premuto.
     * @param e L'evento del mouse
     */
    @Override
    public void mousePressed(MouseEvent e) {
        if(this.contains(e.getPoint()) && canMove){
            dragging = true;
        }
    }

    /**
     * Controlla quando il mouse è rilasciato.
     * @param e L'evento del mouse
     */
    @Override
    public void mouseReleased(MouseEvent e) {
        if(dragging){
            dragging = false;
        }
    }

    /**
     * Controlla quando il mouse entra nel frame.
     * @param e L'evento del mouse
     */
    @Override
    public void mouseEntered(MouseEvent e) {
    }

    /**
     * Controlla quando il mouse esce dal frame.
     * @param e L'evento del mouse
     */
    @Override
    public void mouseExited(MouseEvent e) {
    }

    /**
     * Controlla quando il mouse viene trascinato.
     * @param e L'evento del mouse
     */
    @Override
    public void mouseDragged(MouseEvent e) {
        if(dragging){
            this.x = e.getX() - this.centerX;
            this.y = e.getY() - this.centerY;
            for (CuttingPointListener listener : listeners) {
                listener.CuttingPoint_pointMoved();
            }
        }
    }

    /**
     * Controlla quando il mouse viene mosso.
     * @param e L'evento del mouse
     */
    @Override
    public void mouseMoved(MouseEvent e) {
    }
    
    /**
     * Aggiunge un listener.
     * @param cpl il listener
     */
    public void addCuttingPointListener(CuttingPointListener cpl){
        this.listeners.add(cpl);
    }
    
    /**
     * Rimuove un listener.
     * @param cpl il listener
     */
    public void removeCuttingPointListener(CuttingPointListener cpl){
        this.listeners.remove(cpl);
    }
}