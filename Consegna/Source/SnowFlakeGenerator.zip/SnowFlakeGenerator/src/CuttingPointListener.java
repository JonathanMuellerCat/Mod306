/**
 * Interfaccia di CuttingPoint.
 * @author Jonathan Mueller
 * @version 15.12.2019
 */
public interface CuttingPointListener {
    
    /**
     * Controlla quando il primo punto viene premuto.
     */
    public void CuttingPoint_firstPointClicked();
    
    /**
     * Controlla quando il punto viene mosso.
     */
    public void CuttingPoint_pointMoved();
    
    /**
     * Controlla quando il punto viene rimosso.
     * @param point Il punto rimosso
     */
    public void CuttingPoint_pointRemoved(CuttingPoint point);
}
