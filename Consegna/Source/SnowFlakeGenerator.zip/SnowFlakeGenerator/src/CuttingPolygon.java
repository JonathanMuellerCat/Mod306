
import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;

/**
 * Poligono per tagliare il triangolo
 * @author Jonathan Mueller
 * @version 15.12.2019
 */
public class CuttingPolygon {
    /**
     * I punti del poligono
     */
    private ArrayList<CuttingPoint> points;
    
    /**
     * La posizione x del centro del frame
     */
    private double centerX;
    
    /**
     * La posizione y del centro del frame
     */
    private double centerY;
    
    /**
     * L'altezza del frame
     */
    private double height;
    
    /**
     * La larghezza del frame
     */
    private double width;

    /**
     * Costruttore di CuttingPolygon.
     * @param points  I punti del poligono
     */
    public CuttingPolygon(ArrayList<CuttingPoint> points) {
        this.points = points;
    }

    /**
     * Setter di CuttingPolygon.
     * @param points I punti del poligono
     */
    public void setPoints(ArrayList<CuttingPoint> points) {
        this.points = points;
    }
    
    /**
     * Invoca canMove di tutti i punti.
     */
    public void canMove(boolean canMove){
        for (CuttingPoint point : points) {
            point.canMove(canMove);
        }
    }
    
    /**
     * Ridimensiona il poligono.
     * @param width L'altezza del frame
     * @param height La larghezza del frame
     * @param centerX La posizione x del centro del frame
     * @param centerY La posizione y del centro del frame
     */
    public void setSizeAndPosition(double height, double width, double centerX, double centerY) {
        this.height = height;
        this.width = width;
        this.centerX = centerX;
        this.centerY = centerY;
        for (int i = 0; i < points.size(); i++){
            points.get(i).setSizeAndPosition(width, height, centerX, centerY);
        }
    }
    
    /**
     * Getter per un BetterPolygon basato su questo CuttingPolygon.
     * @return Un BetterPolygon
     */
    public BetterPolygon getPolygon(){
        int[] x = new int[points.size()];
        int[] y = new int[points.size()];
        for (int i = 0; i < points.size(); i++){
            x[i] = (int)Math.round(points.get(i).getX() + centerX);
            y[i] = (int)Math.round(points.get(i).getY() + centerY);
        }
        BetterPolygon p = new BetterPolygon(x, y, points.size());
        return p;
    }
    
    /**
     * Getter per points.
     * @return I punti del poligono
     */
    public ArrayList<CuttingPoint> getPoints(){
        return points;
    }
    
    /**
     * Disegna il poligono.
     * @param g Il contesto grafico
     */
    public void paint(Graphics g){
        Color polygon = new Color(255, 255, 0, 100);
        g.setColor(polygon);
        g.fillPolygon(this.getPolygon());
        for (int i = 0; i < points.size(); i++){
            points.get(i).paint(g);
            if(i > 0){
                points.get(i).setConnectedWith(points.get(i-1));
            }
        }
    }
}
