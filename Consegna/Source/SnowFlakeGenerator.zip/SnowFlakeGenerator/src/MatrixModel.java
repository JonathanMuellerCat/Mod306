/**
 * Modello che fa i calcoli necessari per disegnare una matrice centrata e proporzionata
 * @author Jonathan Mueller
 * @version 13.4.2019
 */
public class MatrixModel{

	/**
	 * Il numero di righe della matrice.
	 */
	private double righe;

	/**
	 * Il numero di colonne della matrice.
	 */
	private double colonne;

	/**
	 * La larghezza della finestra.
	 */
	private double larghezzaFrame;

	/**
	 * L'altezza della finestra.
	 */
	private double altezzaFrame;

	/**
	 * La dimensione del margine.
	 */
	private double marginTop;

	/**
	 * La dimensione del margine.
	 */
	private double marginBottom;

	/**
	 * La dimensione del margine.
	 */
	private double marginLeft;

	/**
	 * La dimensione del margine.
	 */
	private double marginRight;

	/**
	 * La larghezza proporzionale di una cella della matrice.
	 */
	private double proporzioneCellaX;

	/**
	 * L'altezza proporzionale di una cella della matrice.
	 */
	private double proporzioneCellaY;

	/**
	 * Metodo costruttore del matrix model
	 * @param righe il numero di righe della matrice
	 * @param colonne il numero di colonne della matrice
	 * @param larghezzaFrame la larghezza della finestra
	 * @param altezzaFrame l'altezza della finestra
	 * @param proporzioneCellaX la larghezza proporzionale di una cella della matrice
	 * @param proporzioneCellaY l'altezza proporzionale di una cella della matrice
	 */
	public MatrixModel(int righe, int colonne, int larghezzaFrame, int altezzaFrame, int marginTB, int marginLR, int proporzioneCellaX, int proporzioneCellaY){
		this.righe = (double)righe;
		this.colonne = (double)colonne;
		this.larghezzaFrame = (double)larghezzaFrame;
		this.altezzaFrame = (double)altezzaFrame;
		this.marginTop = (double)marginTB;
		this.marginBottom = (double)marginTB;
		this.marginLeft = (double)marginLR;
		this.marginRight = (double)marginLR;
		this.proporzioneCellaX = (double)proporzioneCellaX;
		this.proporzioneCellaY = (double)proporzioneCellaY;
	}

	/**
	 * Calcola la larghezza totale che potrà occupare la tebella.
	 * @return la larghezza della tabella
	 */
	private double getTabellaW(){
		double proporzioneTabellaX = this.proporzioneCellaX * this.colonne;
		double proporzioneTabellaY = this.proporzioneCellaY * this.righe;
		if ((this.larghezzaFrame - this.marginLeft - this.marginRight) / (this.altezzaFrame - this.marginTop - this.marginBottom) < proporzioneTabellaX / proporzioneTabellaY && (this.altezzaFrame - this.marginTop - this.marginBottom) > 0) {
			return (this.larghezzaFrame - this.marginLeft - this.marginRight);
		}else{
			return ((this.altezzaFrame - this.marginTop - this.marginBottom) * (proporzioneTabellaX / proporzioneTabellaY));
		}
	}

	/**
	 * Calcola l'altezza totale che potrà occupare la tebella.
	 * @return l'altezza della tabella
	 */
	private double getTabellaH(){
		double proporzioneTabellaX = this.proporzioneCellaX * this.colonne;
		double proporzioneTabellaY = this.proporzioneCellaY * this.righe;
		if ((this.larghezzaFrame - this.marginLeft - this.marginRight) / (this.altezzaFrame - this.marginTop - this.marginBottom) < proporzioneTabellaX / proporzioneTabellaY && (this.altezzaFrame - this.marginTop - this.marginBottom) > 0) {
			return ((this.larghezzaFrame - this.marginLeft - this.marginRight) * (proporzioneTabellaY / proporzioneTabellaX));
		}else{
			return (this.altezzaFrame - this.marginTop - this.marginBottom);
		}
	}

	/**
	 * Calcola la largezza di una cella.
	 * @return la largezza di una cella
	 */
	public double getCellW(){
		return this.getTabellaW() / this.colonne;
	}

	/**
	 * Calcola l'altezza di una cella.
	 * @return l'altezza di una cella
	 */
	public double getCellH(){
		return this.getTabellaH() / this.righe;
	}

	/**
	 * Calcola lo spazio da destra da cui si può disegnare.
	 * @return lo spazio da destra da cui si può disegnare
	 */
	public double getDX(){
		return (this.larghezzaFrame - this.getTabellaW()) / 2;
	}

	/**
	 * Calcola lo spazio dall'alto da cui si può disegnare.
	 * @return lo spazio dall'alto da cui si può disegnare
	 */
	public double getDY(){
		return (this.altezzaFrame - this.getTabellaH()) / 2;
	}
}
