/**
 * Interfaccia di SavingImageFrame.
 * @author Jonathan Mueller
 * @version 15.12.2019
 */
public interface SavingImageFrameListener {
    /**
     * Controlla quando una immagine viene salvata.
     * @param fileName Il nome del file
     * @param fileExtention L'estenzione del file
     * @param dimentions Le dimensioni del file
     */
    public void SavingImageFrame_saved(String fileName, String fileExtention, String dimentions);
}
