
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.geom.Area;
import java.util.ArrayList;

/**
 * Triangolo che viene tagliato.
 * @author Jonathan Mueller
 * @version 15.12.2019
 */
public class Triangle {
    /**
     * L'altezza del matrix model
     */
    private double size;
    
    /**
     * La posizione x del centro del matrix model
     */
    private double centerX;
    
    /**
     * La posizione y del centro del matrix model
     */
    private double centerY;

    /**
     * Costruttore di Triangle.
     * @param size L'altezza del matrix model
     * @param centerX La posizione x del centro del matrix model
     * @param centerY La posizione y del centro del matrix model
     */
    public Triangle(double size, double centerX, double centerY) {
        this.size = size;
        this.centerX = centerX;
        this.centerY = centerY;
    }
    
    /**
     * Ridimenziona Triangle.
     * @param size L'altezza del matrix model
     * @param centerX La posizione x del centro del matrix model
     * @param centerY La posizione y del centro del matrix model
     */
    public void setSizeAndPosition(double size, double centerX, double centerY) {
        this.size = size;
        this.centerX = centerX;
        this.centerY = centerY;
    }
    
    /**
     * Ritorna il poligono del triangolo.
     * @return Il poligono
     */
    public BetterPolygon getPolygon(){
        ArrayList<Point> punti = new ArrayList<>();
        punti.add(new Point((int)Math.round(this.centerX - (this.size*(0.9) / Math.sqrt(3)) + (this.size*(0.9) / Math.sqrt(3)) / 2), (int)Math.round(this.centerY - this.size*(0.45))));
        punti.add(new Point((int)Math.round(this.centerX + (this.size*(0.9) / Math.sqrt(3)) / 2),(int)Math.round(this.centerY - this.size*(0.45))));
        punti.add(new Point((int)Math.round(this.centerX + (this.size*(0.9) / Math.sqrt(3)) / 2),(int)Math.round(this.centerY + this.size*(0.45))));
        BetterPolygon p = new BetterPolygon(punti);
        return p;
    }
    
    /**
     * Ritorna l'aria con i CuttingPolygon sottratti.
     * @param polygons I CuttingPolygon
     * @return L'area
     */
    public Area getCutArea(ArrayList<CuttingPolygon> polygons){
        BetterPolygon p = this.getPolygon();
        Area cutTriangle = new Area(p);
        for (CuttingPolygon polygon : polygons) {
            cutTriangle.subtract(new Area(polygon.getPolygon()));
        }
        return cutTriangle;
    }
    
    /**
     * Ritorna il poligono con i CuttingPolygon sottratti.
     * @param polygons I CuttingPolygon
     * @return L'area
     */
    public BetterPolygon getPolygonOfCutTriangleV3(ArrayList<CuttingPolygon> polygons){
        Area a = this.getCutArea(polygons);
        BetterPolygon polygon = BetterPolygon.parsePolygon(a);
        return polygon;
    }
    
    /**
     * Disegna il triangolo.
     * @param g Il contesto grafico
     */
    public void paint(Graphics g){
        Color cyan = new Color(0, 255, 255);
        g.setColor(cyan);
        g.fillPolygon(this.getPolygon());
    }
}
