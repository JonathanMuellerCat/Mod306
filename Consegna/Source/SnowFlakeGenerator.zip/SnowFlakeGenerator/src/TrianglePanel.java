import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.filechooser.FileSystemView;

/**
 * Pannello che permette di modificare il triangolo.
 * @author Jonathan Mueller
 * @version 15.12.2019
 */
public class TrianglePanel extends JPanel implements MouseListener, CuttingPointListener, ControlPanelListener, SavingImageFrameListener, TrianglePanelListener {

    /**
     * Il triangolo
     */
    Triangle triangle = new Triangle(0, 0, 0);

    /**
     * La larghezza del MatrixModel
     */
    private double cellW = 0;
    
    /**
     * L'altezza del MatrixModel
     */
    private double cellH = 0;
    
    /**
     * La posizione dx del MatrixModel
     */
    private double dx = 0;
    
    /**
     * La posizione dy del MatrixModel
     */
    private double dy = 0;

    /**
     * I punti posizionati
     */
    private ArrayList<CuttingPoint> points = new ArrayList<>();
    
    /**
     * I poligoni da sottrarre al triangolo
     */
    private ArrayList<CuttingPolygon> polygons = new ArrayList<>();
    
    /**
     * Il fiocco va generato
     */
    private boolean generate = false;
    
    /**
     * Mostra la demo dei tagli
     */
    private boolean showDemo = false;
    
    /**
     * L'angolo di cui il fiocco viene sempre girato alla generazione
     */
    final double STARTING_ANGLE = 0;
    
    /**
     * L'angolo di rotazione del fiocco attuale
     */
    double angle = STARTING_ANGLE;
    
    /**
     * Il timer che permette al fiocco di ruotare
     */
    Timer timer;
    
    /**
     * Il fiocco sta ruotando
     */
    private boolean rotate = false;
    
    /**
     * Il fiocco ha un'ombra
     */
    private boolean shadow = false;
    
    /**
     * Il bordo del MatrixModel
     */
    private int border = 10;
    
    /**
     * Disegna lo sfondo
     */
    private boolean drawBackground = true;
    
    /**
     * La cartella in cui le immagini vanno salvate
     */
    private String imageSavingFolder;
    
    /**
     * Mostra il fiocco
     */
    private boolean show = true;
    
    /**
     * Il colore del fiocco
     */
    private Color mainColor = new Color(0, 255, 255);
    
    /**
     * Il colore dell'ombra
     */
    private Color shadowColor = new Color(0, 0, 0, 50);
    
    /**
     * I listener
     */
    private ArrayList<TrianglePanelListener> listeners = new ArrayList<>();
    
    /**
     * Costruttore di TrianglePanel
     */
    public TrianglePanel() {
        super();
        this.addMouseListener(this);
        this.timer = new Timer(40, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (generate && rotate) {
                    angle+= 0.5;
                    angle = angle % 360;
                    repaint();
                }
            }
        });
        this.timer.start();
    }

    /**
     * Attiva/disattiva la rotazione.
     * @param rotate Il fiocco sta ruotando
     */
    public void setRotate(boolean rotate) {
        this.rotate = rotate;
        this.angle = STARTING_ANGLE;
        repaint();
    }

    /**
     * Setter di shadow.
     * @param shadow Il fiocco ha un'ombra
     */
    public void setShadow(boolean shadow) {
        this.shadow = shadow;
        repaint();
    }

    /**
     * Setter di border.
     * @param border Il bordo del MatrixModel
     */
    public void setBorder(int border) {
        this.border = border;
        repaint();
    }

    /**
     * Setter di polygon.
     * @param polygons I poligoni da sottrarre al triangolo
     */
    public void setPolygons(ArrayList<CuttingPolygon> polygons) {
        this.polygons = polygons;
        repaint();
    }

    /**
     * Setter di drawBackground.
     * @param drawBackground Disegna lo sfondo
     */
    public void setDrawBackground(boolean drawBackground) {
        this.drawBackground = drawBackground;
        repaint();
    }

    /**
     * Setter di show.
     * @param show Mostra il fiocco
     */
    public void setShow(boolean show) {
        this.show = show;
        repaint();
    }

    /**
     * Controlla quando il mouse è cliccato.
     * @param e L'evento del mouse
     */
    @Override
    public void mouseClicked(MouseEvent e) {
        if(matrixContains(e.getPoint()) && !generate && e.getButton() == MouseEvent.BUTTON1){
            this.points.add(new CuttingPoint(e.getX() - (dx + cellW / 2),e.getY() -  (dy + cellH / 2), dx + cellW / 2, dy + cellH / 2, cellW, cellH));
            this.points.get(this.points.size()-1).addCuttingPointListener(this);
            this.addMouseListener(this.points.get(this.points.size()-1));
            this.addMouseMotionListener(this.points.get(this.points.size()-1));
            if(this.points.size() == 1){
                this.points.get(this.points.size()-1).setFirstPoint(true);
            }else{
                this.points.get(this.points.size()-1).setConnectedWith(this.points.get(this.points.size()-2));
                this.points.get(0).setConnectedWith(this.points.get(this.points.size()-1));
            }
            ArrayList<CuttingPolygon> tempPolygons = new ArrayList<>(polygons);
            for (TrianglePanelListener listener : listeners) {
                listener.TrianglePanel_updated(tempPolygons);
            }
            repaint();
        }
    }

    /**
     * Controlla quando il mouse è premuto.
     * @param e L'evento del mouse
     */
    @Override
    public void mousePressed(MouseEvent e) {
    }

    /**
     * Controlla quando il mouse è rilasciato.
     * @param e L'evento del mouse
     */
    @Override
    public void mouseReleased(MouseEvent e) {
    }

    /**
     * Controlla quando il mouse entra nel frame.
     * @param e L'evento del mouse
     */
    @Override
    public void mouseEntered(MouseEvent e) {
    }

    /**
     * Controlla quando il mouse esce dal frame.
     * @param e L'evento del mouse
     */
    @Override
    public void mouseExited(MouseEvent e) {
    }

    /**
     * Controlla quando il primo punto viene premuto.
     */
    @Override
    public void CuttingPoint_firstPointClicked() {
        if(this.points.size() >= 4){
            this.points.remove(this.points.size()-1);
            this.points.get(0).setConnectedWith(this.points.get(this.points.size()-1));
            this.polygons.add(new CuttingPolygon(this.points));
            this.points = new ArrayList<>();
            for (TrianglePanelListener listener : listeners) {
                listener.TrianglePanel_updated(polygons);
            }
            repaint();
        }
    }
    
    /**
     * Controlla quando il punto viene mosso.
     */
    @Override
    public void CuttingPoint_pointMoved() {
        for (TrianglePanelListener listener : listeners) {
            listener.TrianglePanel_updated(polygons);
        }
        repaint();
    }

    /**
     * Controlla quando il punto viene rimosso.
     * @param point Il punto rimosso
     */
    @Override
    public void CuttingPoint_pointRemoved(CuttingPoint point) {
        if (points.contains(point)) {
            if(points.size() == 1){
                point.removeCuttingPointListener(this);
                this.removeMouseListener(point);
                this.removeMouseMotionListener(point);
                points.remove(point);
            }else{
                int index = points.indexOf(point);
                if (index == 0) {
                    points.get(1).setFirstPoint(true);
                    points.get(1).setConnectedWith(points.get(points.size()-1));
                }else if(index == points.size()-1){
                    points.get(0).setConnectedWith(points.get(points.size()-2));
                }else{
                    points.get(index+1).setConnectedWith(points.get(index-1));
                }
                point.removeCuttingPointListener(this);
                this.removeMouseListener(point);
                this.removeMouseMotionListener(point);
                points.remove(point);
            }
            repaint();
        }else{
            for (CuttingPolygon polygon : polygons) {
                ArrayList<CuttingPoint> points = polygon.getPoints();
                if (points.contains(point)) {
                    if(points.size() == 1){
                        point.removeCuttingPointListener(this);
                        this.removeMouseListener(point);
                        this.removeMouseMotionListener(point);
                        points.remove(point);
                    }else{
                        int index = points.indexOf(point);
                        if (index == 0) {
                            points.get(1).setFirstPoint(true);
                            points.get(1).setConnectedWith(points.get(points.size()-1));
                        }else if(index == points.size()-1){
                            points.get(0).setConnectedWith(points.get(points.size()-2));
                        }else{
                            points.get(index+1).setConnectedWith(points.get(index-1));
                        }
                        point.removeCuttingPointListener(this);
                        this.removeMouseListener(point);
                        this.removeMouseMotionListener(point);
                        points.remove(point);
                    }
                    polygon.setPoints(points);
                    repaint();
                }
            }
        }
    }
    
    /**
     * Genera il fiocco.
     */
    public void generate(){
        this.angle = STARTING_ANGLE;
        this.generate = !this.generate;
        repaint();
    }

    /**
     * Controlla quando un bottone viene premuto.
     * @param name Il nome del bottone premuto
     */
    @Override
    public void ControlPanel_buttonClick(String name) {
        if(name.equals("genera")){
            this.angle = STARTING_ANGLE;
            this.generate = !this.generate;
            for (CuttingPolygon polygon : this.polygons) {
                polygon.canMove(!generate);
            }
        }
        if(name.equals("reset")){
            for (CuttingPoint point : points) {
                point.removeCuttingPointListener(this);
                this.removeMouseListener(point);
                this.removeMouseMotionListener(point);
            }
            for (CuttingPolygon poligon : polygons) {
                for (CuttingPoint point : poligon.getPoints()) {
                    point.removeCuttingPointListener(this);
                    this.removeMouseListener(point);
                    this.removeMouseMotionListener(point);
                }
            }
            this.points = new ArrayList<>();
            this.polygons = new ArrayList<>();
            this.generate = false;
            this.showDemo = false;
            ArrayList<CuttingPolygon> tempPolygons = new ArrayList<>();
            for (TrianglePanelListener listener : listeners) {
                listener.TrianglePanel_updated(tempPolygons);
            }
            repaint();
        }
        if(name.equals("showDemo")){
            this.showDemo = !this.showDemo;
        }
        if(name.equals("salvaPunti")){
            JFileChooser fileChooser = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
            fileChooser.setDialogTitle("Salva punti");
            FileNameExtensionFilter filter = new FileNameExtensionFilter("points", "points");
            fileChooser.addChoosableFileFilter(filter);
            fileChooser.setAcceptAllFileFilterUsed(false);

            int returnValue = fileChooser.showSaveDialog(null);
            if (returnValue == JFileChooser.APPROVE_OPTION) {
                File selectedFile = fileChooser.getSelectedFile();
                String nomeFile  = selectedFile.getName();
                String estenzione = "";
                try {
                    estenzione = nomeFile.substring(nomeFile.lastIndexOf(".") + 1, nomeFile.length());
                } catch (StringIndexOutOfBoundsException e) {
                    estenzione = fileChooser.getFileFilter().getDescription();
                }
                String content = "";
                if (estenzione.equals("points")) {
                    try {
                        Path percorso = Paths.get(selectedFile.getAbsolutePath());
                        if(!Files.exists(percorso)){
                            Files.createFile(percorso);
                        }
                        for (CuttingPolygon polygon : polygons) {
                            for (CuttingPoint point : polygon.getPoints()) {
                                content = content + point.getX() / this.cellW + ":" + point.getY() / this.cellH + '\n';
                            }
                            content = content + '\n';
                        }
                        for (int i = 0; i < points.size(); i++) {
                            CuttingPoint point = points.get(i);
                            content = content + point.getX() / this.cellW + ":" + point.getY() / this.cellH;
                            if (i < points.size()-1) {
                                content = content + '\n';
                            }
                        }
                        Files.write(percorso, content.getBytes());
                        JOptionPane.showMessageDialog(null, "File salvato in " + percorso, "Successo", JOptionPane.INFORMATION_MESSAGE);
                    } catch (IOException e) {
                        JOptionPane.showMessageDialog(null, "Errore nella scrittura del file", "Errore", JOptionPane.ERROR_MESSAGE);
                    } 
                }else{
                    JOptionPane.showMessageDialog(null, "Estenzione non valida: scegliere un file .points!!!", "Errore", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
        if(name.equals("caricaPunti")){
            JFileChooser fileChooser = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
            fileChooser.setDialogTitle("Carica punti");
            FileNameExtensionFilter filter = new FileNameExtensionFilter("Points", "points");
            fileChooser.addChoosableFileFilter(filter);
            fileChooser.setAcceptAllFileFilterUsed(false);

            int returnValue = fileChooser.showOpenDialog(null);
            if (returnValue == JFileChooser.APPROVE_OPTION) {
                File selectedFile = fileChooser.getSelectedFile();
                String nomeFile  = selectedFile.getName();
                String estenzione = nomeFile.substring(nomeFile.lastIndexOf(".")+1, nomeFile.length());
                List<String> content;
                if (estenzione.equals("points")) {
                    try {
                        Path percorso = Paths.get(selectedFile.getAbsolutePath());
                        if(Files.exists(percorso)){
                            content = Files.readAllLines(percorso);
                            this.points = new ArrayList<>();
                            this.polygons = new ArrayList<>();
                            this.generate = false;
                            this.showDemo = false;
                            for (String string : content) {
                                if(string.isBlank()){
                                     this.points.get(0).setConnectedWith(this.points.get(this.points.size()-1));
                                     this.polygons.add(new CuttingPolygon(this.points));
                                     this.points = new ArrayList<>();
                                }else{
                                    double relativeX = Double.parseDouble(string.substring(0, string.indexOf(":")-1));
                                    double relativeY = Double.parseDouble(string.substring(string.indexOf(":")+1, string.length()-1));
                                    double x = relativeX * this.cellW;
                                    double y = relativeY * this.cellH;
                                    this.points.add(new CuttingPoint(x, y, dx + cellW / 2, dy + cellW / 2, cellH, cellH));
                                    if(this.points.size() == 1){
                                        this.points.get(this.points.size()-1).setFirstPoint(true);
                                    }else{
                                        this.points.get(this.points.size()-1).setConnectedWith(this.points.get(this.points.size()-2));
                                    }
                                    this.points.get(this.points.size()-1).addCuttingPointListener(this);
                                    this.addMouseListener(this.points.get(this.points.size()-1));
                                    this.addMouseMotionListener(this.points.get(this.points.size()-1));
                                }
                            }
                            ArrayList<CuttingPolygon> tempPolygons = new ArrayList<>(polygons);
                            for (TrianglePanelListener listener : listeners) {
                                listener.TrianglePanel_updated(tempPolygons);
                            }
                            repaint();
                        }
                    } catch (IOException e) {
                        JOptionPane.showMessageDialog(null, "Errore nella lettura del file", "Errore", JOptionPane.ERROR_MESSAGE);
                    } 
                }else{
                    JOptionPane.showMessageDialog(null, "Estenzione non valida: scegliere un file .points!!!", "Errore", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
        if(name.equals("salvaImmagine")){
            JFileChooser fileChooser = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
            fileChooser.setDialogTitle("Salva immagine");
            FileNameExtensionFilter filterPng = new FileNameExtensionFilter("png", "png");
            fileChooser.addChoosableFileFilter(filterPng);
            FileNameExtensionFilter filterSvg = new FileNameExtensionFilter("svg", "svg");
            fileChooser.addChoosableFileFilter(filterSvg);
            fileChooser.setAcceptAllFileFilterUsed(false);

            int returnValue = fileChooser.showSaveDialog(null);
            if (returnValue == JFileChooser.APPROVE_OPTION) {
                String estenzione = "";
                File selectedFile = fileChooser.getSelectedFile();
                String fullNomeFile  = selectedFile.getName();
                String nomeFile = "";
                this.imageSavingFolder = selectedFile.getParent();
                try {
                    nomeFile = fullNomeFile.substring(0, fullNomeFile.lastIndexOf("."));
                    estenzione = fullNomeFile.substring(fullNomeFile.lastIndexOf(".") + 1, fullNomeFile.length());
                } catch (StringIndexOutOfBoundsException e) {
                    nomeFile = fullNomeFile;
                    estenzione = fileChooser.getFileFilter().getDescription();
                }
                if (estenzione.equals("png") || estenzione.equals("svg")) {
                    SavingImageFrame savingImageFrame = new SavingImageFrame(nomeFile, estenzione);
                    savingImageFrame.addSavingImageFrameListener(this);
                    savingImageFrame.setVisible(true);
                }else{
                    JOptionPane.showMessageDialog(null, "Estenzione non valida: scegliere un file .svg o .png!!!", "Errore", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
        repaint();
    }

    /**
     * Controlla se un punto si trova all'interno della matrice.
     * @param p il punto da verificare
     * @return Se il punto si trova all'interno della matrice
     */
    public boolean matrixContains(Point p){
        return ((p.x > this.dx && p.x < this.dx + this.cellW) && (p.y > this.dy && p.y < this.dy + this.cellH));
    }

    /**
     * Disegna nel panel.
     * @param g Il contesto grafico
     */
    @Override
    public void paintComponent(Graphics g) {
        if (drawBackground) {
            g.setColor(Color.WHITE);
            g.fillRect(0, 0, this.getWidth(), this.getHeight());
        }
        if (show) {
            MatrixModel modello = new MatrixModel(1, 1, this.getWidth(), this.getHeight(), border, border, 1, 1);
            this.cellW = modello.getCellW();
            this.cellH = modello.getCellH();
            this.dx = modello.getDX();
            this.dy = modello.getDY();
            this.triangle.setSizeAndPosition(this.cellH, this.dx + this.cellW / 2, this.dy + this.cellH / 2);
            for (int i = 0; i < this.polygons.size(); i++){
                this.polygons.get(i).setSizeAndPosition(this.cellW, this.cellH, this.dx + this.cellW / 2, this.dy + this.cellH / 2);
            }
            for (int i = 0; i < this.points.size(); i++){
                this.points.get(i).setSizeAndPosition(this.cellW, this.cellH, this.dx + this.cellW / 2, this.dy + this.cellH / 2);
                if(i > 0){
                    this.points.get(i).setConnectedWith(this.points.get(i-1));
                }
            }
            if(this.generate){
                Rectangle bounds = this.triangle.getPolygon().getBounds();
                ArrayList<CuttingPolygon> tempPolygons = new ArrayList<>(polygons);
                BetterPolygon finalPolygon = this.triangle.getPolygonOfCutTriangleV3(tempPolygons);
                Point center = new Point((int)Math.round(this.dx + this.cellW / 2), (int)Math.round(this.dy + this.cellH / 2));
                Point top = new Point(
                        (int)Math.round((this.dx + this.cellW / 2)  - (this.cellW*(0.9) / Math.sqrt(3)) + (this.cellW*(0.9) / Math.sqrt(3)) / 2),
                        (int)Math.round((this.dy + this.cellH / 2) - this.cellH*(0.45)));
                BetterPolygon resizedTriangle = this.triangle.getPolygon().getResizedPolygonV3(top, 0.5, bounds);
                BetterPolygon resizedPolygon = finalPolygon.getResizedPolygonV3(top, 0.5, bounds);
                Rectangle tinyBounds = resizedTriangle.getBounds();
                BetterPolygon mirroredfinalPolygon = resizedPolygon.getMirroredPolygon(center, tinyBounds);
                ArrayList<BetterPolygon> fioccoSlices = new ArrayList<>();
                for (int i = 0; i < 6; i++) {
                    fioccoSlices.add(resizedPolygon.getPolygonRotatedAroundPointV3(center, i * 60.0 + this.angle));
                    fioccoSlices.add(mirroredfinalPolygon.getPolygonRotatedAroundPointV3(center, i * 60.0 + this.angle));
                }
                if(this.shadow){
                    for (BetterPolygon fioccoSlice : fioccoSlices) {
                        g.setColor(shadowColor);
                        g.fillPolygon(fioccoSlice.getMovePolygonV3(3, 3));
                    } 
                }
                for (BetterPolygon fioccoSlice : fioccoSlices) {
                    g.setColor(mainColor);
                    g.fillPolygon(fioccoSlice);
                }
            }else if(this.showDemo){
                g.setColor(Color.BLACK);
                g.drawRect((int) this.dx, (int) this.dy, (int) this.cellW, (int) this.cellH);
                g.setColor(mainColor);
                ArrayList<CuttingPolygon> tempPolygons = new ArrayList<>(polygons);
                BetterPolygon cutTriangle = this.triangle.getPolygonOfCutTriangleV3(tempPolygons);
                g.fillPolygon(cutTriangle);
            }else{
                g.setColor(Color.BLACK);
                g.drawRect((int) this.dx, (int) this.dy, (int) this.cellW, (int) this.cellH);
                this.triangle.paint(g);
                for (int i = 0; i < this.polygons.size(); i++){
                    this.polygons.get(i).paint(g);
                }
                for (int i = 0; i < this.points.size(); i++){
                    this.points.get(i).paint(g);
                }
            }
        }
    }

    /**
     * Controlla quando una immagine viene salvata.
     * @param fileName Il nome del file
     * @param fileExtention L'estenzione del file
     * @param dimentions Le dimensioni del file
     */
    @Override
    public void SavingImageFrame_saved(String fileName, String fileExtention, String dimentions) {
        int size = (int)this.cellW;
        try {
            size = Integer.parseInt(dimentions);
        } catch (NumberFormatException e) {
        }
        if (fileExtention.equals("png")) {
            BufferedImage image = new BufferedImage(size, size,BufferedImage.TYPE_INT_ARGB);
            File selected = new File(this.imageSavingFolder + "/" + fileName + "." + fileExtention);
            Graphics g = image.getGraphics();
            MatrixModel modello = new MatrixModel(1, 1, size, size, 25, 25, 1, 1);
            this.cellW = modello.getCellW();
            this.cellH = modello.getCellH();
            this.dx = modello.getDX();
            this.dy = modello.getDY();
            this.triangle.setSizeAndPosition(this.cellH, this.dx + this.cellW / 2, this.dy + this.cellH / 2);
            for (int i = 0; i < this.polygons.size(); i++){
                this.polygons.get(i).setSizeAndPosition(this.cellW, this.cellH, this.dx + this.cellW / 2, this.dy + this.cellH / 2);
            }
            for (int i = 0; i < this.points.size(); i++){
                this.points.get(i).setSizeAndPosition(this.cellW, this.cellH, this.dx + this.cellW / 2, this.dy + this.cellH / 2);
                if(i > 0){
                    this.points.get(i).setConnectedWith(this.points.get(i-1));
                }
            }
            Rectangle bounds = this.triangle.getPolygon().getBounds();
            ArrayList<CuttingPolygon> tempPolygons = new ArrayList<>(polygons);
            BetterPolygon finalPolygon = this.triangle.getPolygonOfCutTriangleV3(tempPolygons);
            Point center = new Point((int)Math.round(this.dx + this.cellW / 2), (int)Math.round(this.dy + this.cellH / 2));
            Point top = new Point(
                    (int)Math.round((this.dx + this.cellW / 2)  - (this.cellW*(0.9) / Math.sqrt(3)) + (this.cellW*(0.9) / Math.sqrt(3)) / 2),
                    (int)Math.round((this.dy + this.cellH / 2) - this.cellH*(0.45)));
            Point center1 = new Point(
                    (int)Math.round((((this.dx + this.cellW / 2) + (this.cellW*(0.9) / Math.sqrt(3)) / 2) - top.x) / 2 + top.x),
                    (int)Math.round((((this.dy + this.cellH / 2) + this.cellH*(0.45)) - top.y) / 2 + top.y));
            BetterPolygon resizedTriangle = this.triangle.getPolygon().getResizedPolygonV3(top, 0.5, bounds);
            BetterPolygon resizedPolygon = finalPolygon.getResizedPolygonV3(top, 0.5, bounds);
            Rectangle tinyBounds = resizedTriangle.getBounds();
            BetterPolygon mirroredfinalPolygon = resizedPolygon.getMirroredPolygon(center, tinyBounds);
            ArrayList<BetterPolygon> fioccoSlices = new ArrayList<>();
            for (int i = 0; i < 6; i++) {
                fioccoSlices.add(resizedPolygon.getPolygonRotatedAroundPointV3(center, i * 60.0 + STARTING_ANGLE));
                fioccoSlices.add(mirroredfinalPolygon.getPolygonRotatedAroundPointV3(center, i * 60.0 + STARTING_ANGLE));
            }
            if(this.shadow){
                for (BetterPolygon fioccoSlice : fioccoSlices) {
                    g.setColor(shadowColor);
                    g.fillPolygon(fioccoSlice.getMovePolygonV3(3, 3));
                } 
            }
            for (BetterPolygon fioccoSlice : fioccoSlices) {
                g.setColor(mainColor);
                g.fillPolygon(fioccoSlice);
            }
            try {
                ImageIO.write(image, "png", selected);
                JOptionPane.showMessageDialog(null, "File salvato in " + this.imageSavingFolder + fileName + "." + fileExtention, "Successo", JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException evt) {
                JOptionPane.showMessageDialog(null, "Errore nella scrittura del file", "Errore", JOptionPane.ERROR_MESSAGE);
            }
        }else if (fileExtention.equals("svg")) {
            MatrixModel modello = new MatrixModel(1, 1, size, size, 25, 25, 1, 1);
            this.cellW = modello.getCellW();
            this.cellH = modello.getCellH();
            this.dx = modello.getDX();
            this.dy = modello.getDY();
            this.triangle.setSizeAndPosition(this.cellH, this.dx + this.cellW / 2, this.dy + this.cellH / 2);
            for (int i = 0; i < this.polygons.size(); i++){
                this.polygons.get(i).setSizeAndPosition(this.cellW, this.cellH, this.dx + this.cellW / 2, this.dy + this.cellH / 2);
            }
            for (int i = 0; i < this.points.size(); i++){
                this.points.get(i).setSizeAndPosition(this.cellW, this.cellH, this.dx + this.cellW / 2, this.dy + this.cellH / 2);
                if(i > 0){
                    this.points.get(i).setConnectedWith(this.points.get(i-1));
                }
            }
            Rectangle bounds = this.triangle.getPolygon().getBounds();
            ArrayList<CuttingPolygon> tempPolygons = new ArrayList<>(polygons);
            BetterPolygon finalPolygon = this.triangle.getPolygonOfCutTriangleV3(tempPolygons);
            Point center = new Point((int)Math.round(this.dx + this.cellW / 2), (int)Math.round(this.dy + this.cellH / 2));
            Point top = new Point(
                    (int)Math.round((this.dx + this.cellW / 2)  - (this.cellW*(0.9) / Math.sqrt(3)) + (this.cellW*(0.9) / Math.sqrt(3)) / 2),
                    (int)Math.round((this.dy + this.cellH / 2) - this.cellH*(0.45)));
            Point center1 = new Point(
                    (int)Math.round((((this.dx + this.cellW / 2) + (this.cellW*(0.9) / Math.sqrt(3)) / 2) - top.x) / 2 + top.x),
                    (int)Math.round((((this.dy + this.cellH / 2) + this.cellH*(0.45)) - top.y) / 2 + top.y));
            BetterPolygon resizedTriangle = this.triangle.getPolygon().getResizedPolygonV3(top, 0.5, bounds);
            BetterPolygon resizedPolygon = finalPolygon.getResizedPolygonV3(top, 0.5, bounds);
            Rectangle tinyBounds = resizedTriangle.getBounds();
            BetterPolygon mirroredfinalPolygon = resizedPolygon.getMirroredPolygon(center, tinyBounds);
            ArrayList<BetterPolygon> fioccoSlices = new ArrayList<>();
            for (int i = 0; i < 6; i++) {
                fioccoSlices.add(resizedPolygon.getPolygonRotatedAroundPointV3(center, i * 60.0 + STARTING_ANGLE));
                fioccoSlices.add(mirroredfinalPolygon.getPolygonRotatedAroundPointV3(center, i * 60.0 + STARTING_ANGLE));
            }
            String svgHeader = "<?xml version=\"1.0\" ?><!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\"><svg width=\"" + size + "px\" height=\"" + size + "px\" xmlns=\"http://www.w3.org/2000/svg\" version=\"1.1\">";
            String svgFooter = "</svg>";
            String polygonHeader = "<path d=\"M";
            String r = Integer.toHexString(mainColor.getRed());
            String g = Integer.toHexString(mainColor.getGreen());
            String b = Integer.toHexString(mainColor.getBlue());
            r = ((r.length() == 1)?("0"):("")) + r;
            g = ((g.length() == 1)?("0"):("")) + g;
            b = ((b.length() == 1)?("0"):("")) + b;
            String color = r + g + b; 
            String polygonFooter = "Z\" fill=\"#" + color + "\" />";
            String svg = svgHeader;
            for (BetterPolygon polygon : fioccoSlices) {
                svg += polygonHeader;
                for (int i = 0; i < polygon.getPoints().size(); i++) {
                    Point point = polygon.getPoints().get(i);
                    if (i > 0) {
                        svg += "L";
                    }
                    svg += (point.getX() + "," + point.getY());
                }
                svg += polygonFooter;
            }
            svg += svgFooter;
            try {
                Path percorso = Paths.get(this.imageSavingFolder + "/" + fileName + "." + fileExtention);
                if(!Files.exists(percorso)){
                    Files.createFile(percorso);
                }
                Files.write(percorso, svg.getBytes());
            } catch (IOException ex) {
                Logger.getLogger(TrianglePanel.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    /**
     * Aggiunge un listener.
     * @param tpl Il listener
     */
    public void addTrianglePanelListener(TrianglePanelListener tpl){
        listeners.add(tpl);
    }
    
    /**
     * Rimuove un listener.
     * @param tpl Il listener
     */
    public void removeTrianglePanelListener(TrianglePanelListener tpl){
        listeners.remove(tpl);
    }
    
    /**
     * Controlla quando i CuttingPolygon sono stati aggiornati.
     * @param polygons I nuovi CuttingPolygon
     */
    @Override
    public void TrianglePanel_updated(ArrayList<CuttingPolygon> polygons) {
        this.polygons = polygons;
        repaint();
    }
}
