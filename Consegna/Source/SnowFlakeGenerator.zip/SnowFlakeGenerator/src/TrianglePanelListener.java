
import java.util.ArrayList;

/**
 * Interfaccia di TrianglePanel.
 * @author Jonathan Mueller
 * @version 15.12.2019
 */
public interface TrianglePanelListener {
    /**
     * Controlla quando i CuttingPolygon sono stati aggiornati.
     * @param polygons I nuovi CuttingPolygon
     */
    public void TrianglePanel_updated(ArrayList<CuttingPolygon> polygons);
}
